TangCell Android

This is an Android WebView wrapper for the tested TangCell Online v16 app.
It opens:
https://tangcellonlinesupabasev16root.vercel.app/

Build with Android Studio:
1. Open this folder as an existing project.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on Android.

No Supabase secret key is included. Login/configuration remains handled by the web app.
