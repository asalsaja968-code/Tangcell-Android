package com.tangcell.app;
import android.annotation.SuppressLint; import android.app.Activity; import android.os.Bundle; import android.webkit.*;
public class MainActivity extends Activity { static final String URL="https://tangcellonlinesupabasev16root-1.vercel.app/"; @SuppressLint("SetJavaScriptEnabled") public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); setContentView(w); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setWebViewClient(new WebViewClient()); w.loadUrl(URL);} }
